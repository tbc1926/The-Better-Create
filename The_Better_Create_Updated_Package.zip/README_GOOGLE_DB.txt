THE BETTER CREATE — общая база

1. Создай Google Таблицу и скопируй ID из URL.
2. Открой https://script.google.com/ и создай новый проект.
3. Вставь Code.gs, замени SPREADSHEET_ID и ADMIN_TOKEN.
4. Сохрани и один раз запусти setup(), выдай разрешения.
5. Deploy → New deployment → Web app → Execute as Me → Who has access: Anyone.
6. Скопируй URL /exec.
7. В index.html найди CONFIG.API_URL и вставь URL.
8. Загрузи index.html на хостинг.

Новости, настройки и сообщества общие для всех. Фото новостей сохраняются в Google Drive.
